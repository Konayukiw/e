package com.anonymous.e.module;

import com.anonymous.e.BlockUtils;
import com.anonymous.e.PlayerControllerAccessor;
import com.anonymous.e.module.setting.impl.ButtonSetting;
import com.anonymous.e.module.setting.impl.SliderSetting;
import net.minecraft.client.Minecraft;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent.Phase;
import org.lwjgl.input.Mouse;

public class Fastmine {

    private static final Minecraft mc = Minecraft.func_71410_x();

    public final SliderSetting delay      = new SliderSetting("Break delay",  " tick", 5.0, 0.0, 5.0, 1.0);
    public final SliderSetting multiplier = new SliderSetting("Break speed",  "x",     1.0, 1.0, 2.0, 0.02);
    public final SliderSetting mode       = new SliderSetting("Mode", 2, new String[]{"Pre", "Post", "Increment"});
    public final ButtonSetting creativeDisable = new ButtonSetting("Disable in creative", true);

    private boolean enabled = false;
    private float lastCurBlockDamageMP = 0.0F;

    public Fastmine() {}

    public void enable() {
        if (!enabled) {
            enabled = true;
            MinecraftForge.EVENT_BUS.register(this);
        }
    }

    public void disable() {
        if (enabled) {
            enabled = false;
            MinecraftForge.EVENT_BUS.unregister(this);
        }
    }

    public boolean isEnabled() {
        return enabled;
    }

    @SubscribeEvent
    public void onPlayerTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != Phase.END) return;
        if (!mc.field_71415_G || !BlockUtils.nullCheck()) return;
        if (creativeDisable.isToggled() && mc.field_71439_g.field_71075_bZ.field_75098_d) return;

        PlayerControllerAccessor controller = PlayerControllerAccessor.of(mc.field_71442_b);

        int delayTarget = (int) delay.getInput();
        if (delayTarget < 5) {
            if (delayTarget == 0) {
                controller.setBlockHitDelay(0);
            } else if (controller.getBlockHitDelay() > delayTarget) {
                controller.setBlockHitDelay(delayTarget);
            }
        }

        double mult = multiplier.getInput();
        if (mult > 1.0) {
            if (!mc.field_71439_g.field_71075_bZ.field_75098_d && Mouse.isButtonDown(0)) {
                float curBlockDamage = controller.getCurBlockDamageMP();
                int modeIndex = (int) mode.getInput();

                switch (modeIndex) {
                    case 0: { // Pre
                        float damage = (float) (1.0 - 1.0 / mult);
                        if (curBlockDamage > 0.0F && curBlockDamage < damage) {
                            controller.setCurBlockDamageMP(damage);
                        }
                        break;
                    }
                    case 1: { // Post
                        double extra = 1.0 / mult;
                        if (curBlockDamage < 1.0F && (double) curBlockDamage >= extra) {
                            controller.setCurBlockDamageMP(1.0F);
                        }
                        break;
                    }
                    case 2: { // Increment
                        float damage2 = -1.0F;
                        if (curBlockDamage < 1.0F) {
                            if (mc.field_71476_x != null && curBlockDamage > lastCurBlockDamageMP) {
                                net.minecraft.block.Block hitBlock =
                                        mc.field_71441_e
                                                .func_180495_p(mc.field_71476_x.func_178782_a())
                                                .func_177230_c();
                                net.minecraft.item.ItemStack heldItem =
                                        mc.field_71439_g.field_71071_by
                                                .func_70301_a(mc.field_71439_g.field_71071_by.field_70461_c);
                                float perTickHardness = BlockUtils.getBlockHardness(
                                        hitBlock, heldItem, false, false);
                                damage2 = (float) (lastCurBlockDamageMP
                                        + perTickHardness * (mult - 0.2152857 * (mult - 1.0)));
                            }
                            if (damage2 != -1.0F && curBlockDamage > 0.0F) {
                                controller.setCurBlockDamageMP(damage2);
                            }
                        }
                        lastCurBlockDamageMP = curBlockDamage;
                        break;
                    }
                }
            } else if (mode.getInput() == 2.0) {
                lastCurBlockDamageMP = 0.0F;
            }
        }
    }

    public String getInfo() {
        double v = multiplier.getInput();
        String val = ((double)((int) v) == v) ? (int) v + "" : String.valueOf(v);
        return val + multiplier.getSuffix();
    }
}
