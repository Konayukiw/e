package com.anonymous.e.agent;

import java.io.File;
import java.lang.instrument.Instrumentation;
import java.lang.reflect.Method;
import java.net.URL;

public final class FastmineAgent {

    private FastmineAgent() {
    }

    public static void premain(String agentArgs, Instrumentation instrumentation) {
        attach(agentArgs);
    }

    public static void agentmain(String agentArgs, Instrumentation instrumentation) {
        attach(agentArgs);
    }

    private static void attach(String agentArgs) {
        try {
            URL jarUrl = FastmineAgent.class.getProtectionDomain()
                    .getCodeSource()
                    .getLocation();
            ClassLoader launchClassLoader = findLaunchClassLoader();

            Method addUrl = launchClassLoader.getClass().getMethod("addURL", URL.class);
            addUrl.invoke(launchClassLoader, jarUrl);

            Class<?> bootstrap = Class.forName(
                    "com.anonymous.e.agent.AgentBootstrap",
                    true,
                    launchClassLoader
            );
            bootstrap.getMethod("install").invoke(null);

            System.out.println("[e-agent] Injected " + new File(jarUrl.toURI()).getName());
        } catch (Throwable t) {
            System.err.println("[e-agent] Injection failed");
            t.printStackTrace();
        }
    }

    private static ClassLoader findLaunchClassLoader() throws Exception {
        Class<?> launch = Class.forName("net.minecraft.launchwrapper.Launch");
        Object classLoader = launch.getField("classLoader").get(null);
        if (!(classLoader instanceof ClassLoader)) {
            throw new IllegalStateException("Launch.classLoader is not a ClassLoader");
        }
        return (ClassLoader) classLoader;
    }
}
