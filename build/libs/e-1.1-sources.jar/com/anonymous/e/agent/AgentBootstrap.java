package com.anonymous.e.agent;

import com.anonymous.e.e;
import net.minecraft.client.Minecraft;

public final class AgentBootstrap {

    private static boolean scheduled;

    private AgentBootstrap() {
    }

    public static synchronized void install() {
        if (scheduled || e.isInitialized()) {
            return;
        }
        scheduled = true;

        final Minecraft minecraft = Minecraft.func_71410_x();
        Runnable initializer = new Runnable() {
            @Override
            public void run() {
                try {
                    e.initInjected();
                } catch (Throwable t) {
                    System.err.println("[e-agent] Bootstrap failed");
                    t.printStackTrace();
                }
            }
        };

        if (minecraft.func_152345_ab()) {
            initializer.run();
        } else {
            minecraft.func_152344_a(initializer);
        }
    }
}
