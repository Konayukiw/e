package com.anonymous.e;

import net.minecraft.block.Block;
import net.minecraft.block.material.Material;
import net.minecraft.client.Minecraft;
import net.minecraft.enchantment.Enchantment;
import net.minecraft.enchantment.EnchantmentHelper;
import net.minecraft.item.ItemStack;
import net.minecraft.potion.Potion;

public class BlockUtils {

    private static final Minecraft mc = Minecraft.func_71410_x();

    public static float getBlockHardness(Block block, ItemStack itemStack, boolean ignoreSlow, boolean ignoreGround) {
        float hardness = block.func_176195_g(mc.field_71441_e, null);
        if (hardness < 0.0F) {
            return 0.0F;
        }

        boolean canHarvest = block.func_149688_o().func_76229_l()
                || (itemStack != null && itemStack.func_150998_b(block));

        float efficiency = getToolDigEfficiency(itemStack, block, ignoreSlow, ignoreGround);

        return canHarvest
                ? efficiency / hardness / 30.0F
                : efficiency / hardness / 100.0F;
    }

    private static float getToolDigEfficiency(ItemStack itemStack, Block block, boolean ignoreSlow, boolean ignoreGround) {
        float n = (itemStack == null) ? 1.0F : itemStack.func_77973_b().func_150893_a(itemStack, block);

        if (n > 1.0F) {
            int effLevel = EnchantmentHelper.func_77506_a(Enchantment.field_77349_p.field_77352_x, itemStack);
            if (effLevel > 0 && itemStack != null) {
                n += (float) (effLevel * effLevel + 1);
            }
        }

        if (mc.field_71439_g.func_70644_a(Potion.field_76422_e)) {
            n *= 1.0F + (float) (mc.field_71439_g.func_70660_b(Potion.field_76422_e).func_76458_c() + 1) * 0.2F;
        }

        if (!ignoreSlow) {
            if (mc.field_71439_g.func_70644_a(Potion.field_76419_f)) {
                float slowMult;
                switch (mc.field_71439_g.func_70660_b(Potion.field_76419_f).func_76458_c()) {
                    case 0:  slowMult = 0.3F;     break;
                    case 1:  slowMult = 0.09F;    break;
                    case 2:  slowMult = 0.0027F;  break;
                    default: slowMult = 8.1E-4F;  break;
                }
                n *= slowMult;
            }

            if (mc.field_71439_g.func_70055_a(Material.field_151586_h)
                    && !EnchantmentHelper.func_77510_g(mc.field_71439_g)) {
                n /= 5.0F;
            }

            if (!mc.field_71439_g.field_70122_E && !ignoreGround) {
                n /= 5.0F;
            }
        }

        return n;
    }

    public static boolean nullCheck() {
        return mc.field_71439_g != null && mc.field_71441_e != null;
    }
}