package com.anonymous.e;

import com.anonymous.e.module.FastMine;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.common.Mod.EventHandler;
import net.minecraftforge.fml.common.event.FMLInitializationEvent;

@Mod(
        modid = "Xk7mQ2pR",
        name = "e",
        version = "1.0.0",
        acceptedMinecraftVersions = "[1.8.9]"
)
public class e {

    public static FastMine fastMine;
    public static ConfigUtils configUtils;

    public e() {
    }

    @EventHandler
    public void init(FMLInitializationEvent event) {
        fastMine      = new FastMine();
        configUtils = new ConfigUtils();

        configUtils.load(fastMine);

        if (!fastMine.isEnabled()) {
            fastMine.enable();
            configUtils.save(fastMine);
        }

        ClientCommandHandler.instance.func_71560_a(
                new ICommand(fastMine, configUtils)
        );
    }
}
